export class ResultDTO{  
    resultIdnumber!: number;
    attemptedQs!: number;
    crctAns!: number;
    incrctAns!: number;
	marks!: number;
    nonAttemptedQs!: number;
    percentage!: number;
    status!: string;
    examId!: number;
    userId!: number;
    levelId!: number;
}
	