import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-elements-details-dialog',
  templateUrl: './dialog-elements-details-dialog.component.html',
  styleUrls: ['./dialog-elements-details-dialog.component.css']
})
export class DialogElementsDetailsDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
