import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-contact',
  templateUrl: './settings-contact.component.html',
  styleUrls: ['./settings-contact.component.css']
})
export class SettingsContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
