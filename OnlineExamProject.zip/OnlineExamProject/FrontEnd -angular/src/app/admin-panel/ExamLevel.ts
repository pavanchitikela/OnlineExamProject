export class ExamLevel{
    levelId!: number;
	cutoffMarks!: number;
    duration!: number;
	totalQs!: number;
}