package com.lti.service;

import com.lti.dto.EmploymentDto;

public interface EmploymentDetailService {

	public String insertEmploymentDetailService(EmploymentDto employmentDto);
}
